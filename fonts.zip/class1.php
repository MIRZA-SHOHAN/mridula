<?php
    $number = 122;
    // echo "This is:";
    // echo $number;

    if($number == 12){
        echo "This is tweelve";
    }else{
        echo "This is not tweelve";
    }

    for($i=0; $i<34; $i++ ){
        echo "Subhanallah.". "<br>";
    }

?>